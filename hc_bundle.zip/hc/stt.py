"""Speech-to-text for voice notes, run locally with faster-whisper (supports Hindi/English/Hinglish).
First use downloads the model (base ~150 MB; set WHISPER_MODEL=small for better Hindi)."""
import os

_model = None
PROMPT = "roti, dal, chawal, sabzi, paneer, idli, dosa, dahi, katori, bhindi, rajma, chole, poha, upma, paratha"


class SpeechUnavailable(Exception):
    pass


def transcribe(path: str) -> str:
    global _model
    try:
        if _model is None:
            from faster_whisper import WhisperModel
            _model = WhisperModel(os.getenv("WHISPER_MODEL", "base"), device="cpu", compute_type="int8")
        segments, _ = _model.transcribe(path, initial_prompt=PROMPT, vad_filter=True)
        return " ".join(s.text.strip() for s in segments).strip()
    except Exception as e:  # noqa: BLE001 - missing package, offline model download, bad audio
        raise SpeechUnavailable(f"{type(e).__name__}: {e}") from e
