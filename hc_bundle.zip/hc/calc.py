"""Deterministic nutrition/target calculations. No AI involved here."""
from dataclasses import dataclass, field

GOALS = ["Weight loss", "Weight gain", "Muscle building"]
SEXES = ["Female", "Male"]
DIETS = ["Vegetarian", "Vegan", "Non-vegetarian", "Lactose-free"]
ACTIVITY_LEVELS = {
    "Sedentary (desk job, little exercise)": 1.2,
    "Lightly active (1-3 workouts/week)": 1.375,
    "Moderately active (3-5 workouts/week)": 1.55,
    "Very active (6-7 hard workouts/week)": 1.725,
}
CONDITIONS = [
    "Type 2 diabetes", "Type 1 diabetes", "Hypertension", "High cholesterol",
    "Thyroid disorder", "PCOS", "Heart disease", "Kidney disease",
    "Pregnant or breastfeeding", "History of eating disorder", "Gout", "IBS / digestive disorder",
]
# Conditions where we do not push targets and refer to a professional.
COMPLEX_CONDITIONS = {
    "Type 1 diabetes", "Heart disease", "Kidney disease",
    "Pregnant or breastfeeding", "History of eating disorder",
}
# Approximate MET values (Compendium of Physical Activities, rounded).
ACTIVITY_METS = {
    "Walking (easy)": 3.5, "Brisk walking": 4.3, "Jogging / running": 9.0,
    "Cycling": 7.5, "Yoga": 2.5, "Surya Namaskar": 3.3, "Strength training": 5.0,
    "HIIT": 8.0, "Swimming": 6.0, "Badminton": 5.5, "Cricket": 4.8, "Dancing / Zumba": 5.0,
}
DISCLAIMER = (
    "These recommendations are for educational purposes only and assume that the information and "
    "health conditions you provided are accurate. Consult your doctor before making dietary, exercise "
    "or consumption changes, particularly if you have a medical condition or take medication."
)
KCAL_PER_KG = 7700  # common approximation for body-fat energy


def bmi(weight_kg: float, height_cm: float) -> float:
    return weight_kg / ((height_cm / 100) ** 2)


def bmr_mifflin(sex: str, weight_kg: float, height_cm: float, age: int) -> float:
    base = 10 * weight_kg + 6.25 * height_cm - 5 * age
    return base + (5 if sex == "Male" else -161)


def activity_calories(activity: str, weight_kg: float, minutes: float) -> float:
    return ACTIVITY_METS[activity] * weight_kg * (minutes / 60)


def steps_calories(steps: int, weight_kg: float) -> float:
    """Rough estimate: ~0.04 kcal/step for a 70 kg person, scaled by body weight."""
    return steps * 0.04 * (weight_kg / 70)


def validate_profile(p: dict) -> list[str]:
    errs = []
    if not 14 <= p["age"] <= 100: errs.append("Age must be between 14 and 100.")
    if not 100 <= p["height_cm"] <= 250: errs.append("Height must be between 100 and 250 cm.")
    if not 25 <= p["weight_kg"] <= 300: errs.append("Weight must be between 25 and 300 kg.")
    if not 25 <= p["target_weight_kg"] <= 300: errs.append("Target weight must be between 25 and 300 kg.")
    if not 1 <= p["timeline_weeks"] <= 156: errs.append("Timeline must be between 1 and 156 weeks.")
    if p["sex"] not in SEXES: errs.append("Select a sex.")
    if p["goal"] not in GOALS: errs.append("Select a goal.")
    if p["diet"] not in DIETS: errs.append("Select a dietary preference.")
    if p["activity_level"] not in ACTIVITY_LEVELS: errs.append("Select an activity level.")
    return errs


@dataclass
class Targets:
    bmr: float
    tdee: float
    calories: int
    protein_g: int
    carbs_g: int
    fat_g: int
    sugar_g: int
    water_ml: int
    weekly_change_kg: float
    weeks_to_target: float | None
    bmi: float
    refer_professional: bool = False
    warnings: list = field(default_factory=list)  # (level, message): level in {"error","warning","info"}


def compute_targets(p: dict) -> Targets:
    w, h, age, sex = p["weight_kg"], p["height_cm"], p["age"], p["sex"]
    conds = set(p.get("conditions") or [])
    warns: list = []
    bmr = bmr_mifflin(sex, w, h, age)
    tdee = bmr * ACTIVITY_LEVELS[p["activity_level"]]
    cur_bmi = bmi(w, h)
    goal = p["goal"]
    weeks = max(1, p["timeline_weeks"])
    delta_kg = p["target_weight_kg"] - w  # + gain, - loss
    refer = bool(conds & COMPLEX_CONDITIONS)
    floor = 1500 if sex == "Male" else 1200

    if refer:
        warns.append(("error", "Your medical profile (" + ", ".join(sorted(conds & COMPLEX_CONDITIONS)) +
                      ") needs individual guidance. The numbers below are general maintenance estimates only - "
                      "please work with a doctor or registered dietitian before following any plan."))
    if age < 18:
        warns.append(("error", "Under 18: growth needs differ. Targets are set to maintenance; "
                               "see a paediatrician or dietitian before any weight change."))
    if goal == "Weight loss" and delta_kg >= 0:
        warns.append(("warning", "Your target weight is not below your current weight, which conflicts with a weight-loss goal."))
    if goal == "Weight gain" and delta_kg <= 0:
        warns.append(("warning", "Your target weight is not above your current weight, which conflicts with a weight-gain goal."))

    adjust = 0.0  # kcal/day relative to maintenance
    if refer or age < 18:
        adjust = 0.0
    elif goal == "Weight loss":
        if cur_bmi < 18.5:
            warns.append(("error", f"Your BMI ({cur_bmi:.1f}) is already below 18.5 (underweight). Weight loss is not advised - consult a doctor."))
        else:
            if bmi(p["target_weight_kg"], h) < 18.5:
                warns.append(("error", "Your target weight corresponds to an underweight BMI (<18.5). Please choose a healthier target."))
            need = max(0.0, -delta_kg) * KCAL_PER_KG / (weeks * 7)
            cap = min(750.0, 0.30 * tdee)
            adjust = -min(need, cap)
            weekly_need = max(0.0, -delta_kg) / weeks
            if weekly_need > 1.0 or weekly_need > 0.01 * w:
                warns.append(("warning", f"Unrealistic timeline: reaching your target needs ~{weekly_need:.2f} kg/week. "
                                         "A safe pace is about 0.25-0.75 kg/week (max ~1% of body weight). "
                                         "Your plan is capped at a safe deficit, so it will take longer."))
            if need > cap * 1.0 and need > 1000:
                warns.append(("error", "Crash diets are unsafe. Do not cut calories this aggressively."))
    elif goal == "Weight gain":
        need = max(0.0, delta_kg) * KCAL_PER_KG / (weeks * 7)
        adjust = min(need, 500.0) if need else 300.0
        if max(0.0, delta_kg) / weeks > 0.5:
            warns.append(("warning", "Gaining more than ~0.5 kg/week is mostly fat. Plan capped at a +500 kcal/day surplus."))
    else:  # Muscle building
        adjust = 250.0
        if delta_kg < 0:
            warns.append(("info", "For muscle building a small surplus (+250 kcal) is used; a target below current weight is ignored for calories."))

    calories = tdee + adjust
    if calories < floor and not (refer or age < 18):
        warns.append(("warning", f"Calories were raised to the minimum safe floor of {floor} kcal/day for {sex.lower()}s."))
        calories = floor
    calories = int(round(calories / 10) * 10)

    # Protein
    if "Kidney disease" in conds:
        pg_kg = 0.8
    else:
        pg_kg = {"Weight loss": 1.6, "Weight gain": 1.4, "Muscle building": 1.8}[goal]
    protein = pg_kg * w
    protein = min(protein, 0.35 * calories / 4)
    fat = 0.25 * calories / 9
    carbs = max(0.0, (calories - protein * 4 - fat * 9) / 4)
    sugar = 0.10 * calories / 4  # keep free sugars under 10% of energy
    water = int(round(35 * w / 50) * 50)

    if conds & {"Type 2 diabetes", "Type 1 diabetes"}:
        warns.append(("warning", "Diabetes: carbohydrate timing and medication matter. Share this plan with your doctor/dietitian."))
    if "Hypertension" in conds:
        warns.append(("info", "Hypertension: keep salt low (< 5 g/day) and limit pickles, papad and processed snacks."))

    weekly = (calories - tdee) * 7 / KCAL_PER_KG
    weeks_to = None
    if weekly and delta_kg and (weekly > 0) == (delta_kg > 0):
        weeks_to = abs(delta_kg / weekly)
    return Targets(round(bmr), round(tdee), calories, int(round(protein)), int(round(carbs)), int(round(fat)),
                   int(round(sugar)), water, round(weekly, 2), weeks_to, round(cur_bmi, 1), refer, warns)


def sum_nutrition(rows) -> dict:
    keys = ("kcal", "protein", "carbs", "fat", "sugar")
    return {k: round(sum((r[k] or 0) for r in rows), 1) for k in keys}


def scale_food(food: dict, grams: float) -> dict:
    f = grams / 100.0
    return {k: round(food[k] * f, 1) for k in ("kcal", "protein", "carbs", "fat", "sugar")}
