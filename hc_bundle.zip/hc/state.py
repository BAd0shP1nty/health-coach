"""Shared read helpers used by every front end (chat agent, Streamlit): current profile, targets, day summary."""
from . import calc, db


def current_profile():
    """(profile, targets) with weight replaced by the latest logged weight, or (None, None)."""
    p = db.get_profile()
    if not p:
        return None, None
    ws = db.get_weights()
    if ws:
        p = {**p, "weight_kg": ws[-1]["weight_kg"]}
    return p, calc.compute_targets(p)


def remaining_for(targets, consumed: dict) -> dict:
    return {"kcal": max(0, targets.calories - consumed["kcal"]), "protein": max(0, targets.protein_g - consumed["protein"]),
            "carbs": max(0, targets.carbs_g - consumed["carbs"]), "fat": max(0, targets.fat_g - consumed["fat"]),
            "sugar": max(0, targets.sugar_g - consumed["sugar"])}


def day_summary(day: str) -> dict | None:
    p, t = current_profile()
    if not p:
        return None
    meals, acts, daily = db.get_meals(day), db.get_activities(day), db.get_daily(day)
    n = calc.sum_nutrition(meals)
    return {
        "day": day,
        "targets": {"kcal": t.calories, "protein_g": t.protein_g, "carbs_g": t.carbs_g, "fat_g": t.fat_g,
                    "sugar_max_g": t.sugar_g, "water_ml": t.water_ml},
        "consumed": {"kcal": n["kcal"], "protein_g": n["protein"], "carbs_g": n["carbs"], "fat_g": n["fat"], "sugar_g": n["sugar"]},
        "remaining": {k: round(v, 1) for k, v in remaining_for(t, n).items()},
        "meals": [{"id": m["id"], "type": m["meal_type"], "item": m["item"], "grams": m["quantity_g"], "kcal": round(m["kcal"]),
                   "source": m["source"]} for m in meals],
        "exercise": [{"id": a["id"], "name": a["name"], "minutes": a["minutes"], "kcal": round(a["kcal"])} for a in acts],
        "water_ml": daily["water_ml"], "steps": daily["steps"],
        "weight_kg": p["weight_kg"], "target_weight_kg": p["target_weight_kg"],
        "warnings": [m for _, m in t.warnings], "refer_professional": t.refer_professional,
    }
