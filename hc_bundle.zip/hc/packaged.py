"""Packaged-food lookup via Open Food Facts (open, crowd-sourced label data; ODbL licence).
Needs internet. Values are what manufacturers print on the pack - always verify against your pack."""
import requests

BASE = "https://world.openfoodfacts.org"
HEADERS = {"User-Agent": "AIHealthCoach/1.0 (personal local app)"}
FIELDS = "code,product_name,brands,nutriments,serving_quantity,serving_size,allergens_tags,ingredients_analysis_tags"
SOURCE = "Open Food Facts (crowd-sourced label data - verify on pack)"


class PackagedUnavailable(Exception):
    pass


def _num(n: dict, key: str):
    v = n.get(key)
    try:
        return None if v in (None, "") else float(v)
    except (TypeError, ValueError):
        return None


def parse_product(p: dict) -> dict | None:
    """Turn an Open Food Facts product into our per-100 g food dict, or None if energy is missing."""
    n = p.get("nutriments") or {}
    kcal = _num(n, "energy-kcal_100g")
    if kcal is None and _num(n, "energy_100g") is not None:
        kcal = _num(n, "energy_100g") / 4.184  # kJ -> kcal
    name = (p.get("product_name") or "").strip()
    if kcal is None or not name:
        return None
    brand = (p.get("brands") or "").split(",")[0].strip()
    tags = p.get("ingredients_analysis_tags") or []
    diet = ("vegan" if "en:vegan" in tags else "vegetarian" if "en:vegetarian" in tags
            else "nonveg" if "en:non-vegetarian" in tags else "unknown")
    allergens = [t.split(":")[-1].replace("-", " ") for t in (p.get("allergens_tags") or [])]
    try:
        serving = float(p.get("serving_quantity") or 0) or 100.0
    except (TypeError, ValueError):
        serving = 100.0
    return dict(
        name=f"{brand} {name}".strip() if brand and brand.lower() not in name.lower() else name,
        category="Packaged (Open Food Facts)", source=SOURCE, barcode=p.get("code", ""),
        kcal=round(kcal, 1), protein=round(_num(n, "proteins_100g") or 0, 1), carbs=round(_num(n, "carbohydrates_100g") or 0, 1),
        fat=round(_num(n, "fat_100g") or 0, 1), sugar=round(_num(n, "sugars_100g") or 0, 1),
        unit_name=p.get("serving_size") or "100 g", unit_g=serving, diet=diet,
        dairy="milk" in allergens, allergens=allergens)


def _get(url: str, params: dict) -> dict:
    try:
        r = requests.get(url, params=params, headers=HEADERS, timeout=20)
        r.raise_for_status()
        return r.json()
    except (requests.RequestException, ValueError) as e:
        raise PackagedUnavailable(f"Could not reach Open Food Facts ({type(e).__name__}). Check your internet connection, "
                                  "or enter the values from the pack label instead.") from e


def search(query: str, limit: int = 10) -> list[dict]:
    """Search by product name/brand (India first), or by barcode if the query is all digits."""
    q = query.strip()
    if not q:
        return []
    if q.isdigit() and len(q) >= 8:
        data = _get(f"{BASE}/api/v2/product/{q}.json", {"fields": FIELDS})
        found = [data["product"]] if data.get("status") == 1 and data.get("product") else []
    else:
        params = {"search_terms": q, "search_simple": 1, "action": "process", "json": 1, "page_size": limit * 2,
                  "fields": FIELDS, "tagtype_0": "countries", "tag_contains_0": "contains", "tag_0": "india"}
        found = _get(f"{BASE}/cgi/search.pl", params).get("products", [])
    out = [f for f in (parse_product(p) for p in found) if f]
    return out[:limit]
