"""Terminal chat for testing the agent without Telegram:  python -m hc.chat  """
from dotenv import load_dotenv

from . import agent

load_dotenv()


def main():
    print("AI Health Coach (Ctrl+C to quit)")
    while True:
        line = input("you> ").strip()
        print("coach>", agent.respond("cli", line), "\n")


if __name__ == "__main__":
    main()
