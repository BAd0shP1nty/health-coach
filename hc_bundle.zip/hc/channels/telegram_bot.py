"""Telegram front end: text and voice notes -> agent. Run:  python -m hc.channels.telegram_bot"""
import asyncio
import logging
import os
import tempfile
from datetime import time as dtime
from zoneinfo import ZoneInfo

from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, TypeHandler, filters

from .. import agent, db, stt

load_dotenv()
log = logging.getLogger("healthcoach")
HELP = ("I'm your AI health coach. Just talk to me:\n"
        "- Send a VOICE note or type what you ate\n"
        "- Ask \"what should I eat next?\" or \"plan my day\"\n"
        "- Tell me your weight, workouts, water and steps\n\n"
        "Commands: /checkin on 20:30 (daily nudge) · /checkin off · /privacy · /delete_my_data\n"
        "Educational use only - not medical advice.")
PRIVACY = ("Privacy: your profile, meals, notes and chat history are stored on this bot's server in a private folder just for you. "
           "To answer, the coach sends your messages and the relevant parts of your data to the DeepSeek API (a China-based provider), "
           "Voice notes are transcribed on the server and not stored. /delete_my_data erases everything.")


def allowed(uid: int) -> bool:
    ids = [i.strip() for i in os.getenv("TELEGRAM_ALLOWED_IDS", "").split(",") if i.strip()]
    return not ids or str(uid) in ids


async def deny(update: Update):
    """Not on the allow-list: say so (and show their real ID) instead of staying silent."""
    uid = update.effective_user.id
    log.warning("blocked message from user id %s (not in TELEGRAM_ALLOWED_IDS)", uid)
    await update.message.reply_text(f"This bot is private. Your Telegram user ID is {uid}. "
                                    "If you run this bot, add that number to TELEGRAM_ALLOWED_IDS in .env and restart it.")


async def reply(update: Update, text: str):
    for i in range(0, len(text), 4000):
        await update.message.reply_text(text[i:i + 4000])


async def ask(update: Update, text: str, images=None):
    uid = update.effective_user.id
    await update.message.chat.send_action(ChatAction.TYPING)
    out = await asyncio.to_thread(agent.respond, uid, text, images)
    await reply(update, out)


async def on_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not allowed(update.effective_user.id):
        return await deny(update)
    await ask(update, update.message.text)


async def on_photo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Photo reading is switched off for now (the vision code is kept in hc/vision.py)."""
    if not allowed(update.effective_user.id):
        return await deny(update)
    await reply(update, "I can't read photos yet. Please tell me what you ate by text or voice note, "
                        "for example \"2 roti, 1 katori dal, some sabzi\".")


async def on_voice(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not allowed(update.effective_user.id):
        return await deny(update)
    media = update.message.voice or update.message.audio
    f = await media.get_file()
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "voice.ogg")
        await f.download_to_drive(path)
        try:
            heard = await asyncio.to_thread(stt.transcribe, path)
        except stt.SpeechUnavailable:
            return await reply(update, "I couldn't understand that voice note. Please type it instead.")
    if not heard:
        return await reply(update, "I couldn't hear anything in that voice note. Could you try again or type it?")
    await reply(update, f"🎙 I heard: {heard}")
    await ask(update, f"(voice message transcript, may contain mistakes) {heard}")


async def cmd_start(update: Update, ctx):
    if not allowed(update.effective_user.id):
        return await deny(update)
    await reply(update, HELP)
    await ask(update, "Hi! I just opened the chat.")


async def cmd_help(update: Update, ctx):
    await reply(update, HELP)


async def cmd_privacy(update: Update, ctx):
    await reply(update, PRIVACY)


async def cmd_delete(update: Update, ctx):
    if ctx.user_data.get("confirm_delete"):
        db.delete_user_data(update.effective_user.id)
        from .. import rag
        rag._client.cache_clear()
        ctx.user_data.clear()
        for j in ctx.job_queue.get_jobs_by_name(str(update.effective_user.id)):
            j.schedule_removal()
        return await reply(update, "Done - all your data has been erased.")
    ctx.user_data["confirm_delete"] = True
    await reply(update, "This permanently erases your profile, meals, notes and history. Send /delete_my_data again to confirm, or anything else to cancel.")


async def cancel_delete(update: Update, ctx):
    ctx.user_data.pop("confirm_delete", None)
    await on_text(update, ctx)


def schedule_checkin(app: Application, uid: str, hhmm: str):
    for j in app.job_queue.get_jobs_by_name(uid):
        j.schedule_removal()
    h, m = (int(x) for x in hhmm.split(":"))
    app.job_queue.run_daily(checkin_job, dtime(h, m, tzinfo=ZoneInfo(os.getenv("HC_TZ", "Asia/Kolkata"))), name=uid, chat_id=int(uid), data=uid)


async def checkin_job(ctx: ContextTypes.DEFAULT_TYPE):
    uid = ctx.job.data
    out = await asyncio.to_thread(agent.respond, uid, "[CHECK-IN] Send my brief daily check-in.")
    await ctx.bot.send_message(chat_id=int(uid), text=out)


async def cmd_checkin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    arg = (ctx.args[0].lower() if ctx.args else "")
    if arg == "off":
        for j in ctx.job_queue.get_jobs_by_name(uid):
            j.schedule_removal()
        with db.use_user(uid):
            db.set_setting("checkin", "")
        return await reply(update, "Daily check-ins are off.")
    t = ctx.args[1] if arg == "on" and len(ctx.args) > 1 else "20:30"
    try:
        schedule_checkin(ctx.application, uid, t)
    except ValueError:
        return await reply(update, "Use it like: /checkin on 20:30   or   /checkin off")
    with db.use_user(uid):
        db.set_setting("checkin", t)
    await reply(update, f"I'll check in with you daily at {t}. /checkin off to stop.")


async def restore_checkins(app: Application):
    for uid in db.list_users():
        with db.use_user(uid):
            t = db.get_setting("checkin")
        if t:
            schedule_checkin(app, uid, t)


async def log_update(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Make activity visible in the bot window (does not stop other handlers)."""
    m = update.message
    if m and update.effective_user:
        kind = "voice" if (m.voice or m.audio) else "photo" if m.photo else "command" if (m.text or "").startswith("/") else "text"
        log.info("incoming %s from user id %s", kind, update.effective_user.id)


async def on_error(update, ctx: ContextTypes.DEFAULT_TYPE):
    log.error("handler error", exc_info=ctx.error)
    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text("Sorry, something went wrong on my side. Please try again.")
        except Exception:  # noqa: BLE001
            pass


async def post_init(app: Application):
    try:
        me = await app.bot.get_me()
        log.info("Bot is live as @%s - message exactly this bot in Telegram. Waiting for messages...", me.username)
    except Exception as e:  # noqa: BLE001
        log.error("Cannot reach Telegram (%s). Check your token, internet, VPN or firewall. Run run_doctor.bat.", type(e).__name__)
    await restore_checkins(app)


def main():
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise SystemExit("Set TELEGRAM_BOT_TOKEN in .env (create a bot with @BotFather on Telegram).")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    app = Application.builder().token(token).post_init(post_init).build()
    app.add_handler(TypeHandler(Update, log_update), group=-1)
    app.add_error_handler(on_error)
    for name, fn in [("start", cmd_start), ("help", cmd_help), ("privacy", cmd_privacy), ("delete_my_data", cmd_delete), ("checkin", cmd_checkin)]:
        app.add_handler(CommandHandler(name, fn))
    app.add_handler(MessageHandler(filters.PHOTO, on_photo))
    app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO, on_voice))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, cancel_delete))
    app.run_polling()


if __name__ == "__main__":
    main()
