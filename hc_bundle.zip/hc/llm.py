"""Minimal OpenAI-compatible chat client (DeepSeek by default). Normalises failures into a few exception types."""
import os
import time

import requests


class LLMError(Exception):
    pass


class LLMAuthError(LLMError):
    pass


class LLMBusy(LLMError):
    pass


class LLMUnavailable(LLMError):
    pass


def configured(key_env: str = "DEEPSEEK_API_KEY") -> bool:
    k = os.getenv(key_env, "").strip()
    return bool(k) and not k.startswith("your_")


def chat(messages: list, tools: list | None = None, model: str | None = None, base_url: str | None = None,
         api_key: str | None = None, max_tokens: int = 2000, timeout: int = 45) -> dict:
    """POST /chat/completions and return the first choice: {"message": {...}, "finish_reason": "..."}."""
    key = (api_key or os.getenv("DEEPSEEK_API_KEY", "")).strip()
    if not key or key.startswith("your_"):
        raise LLMAuthError("no API key configured")
    url = (base_url or os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")).rstrip("/") + "/chat/completions"
    body = {"model": model or os.getenv("AGENT_MODEL", "deepseek-chat"), "messages": messages, "max_tokens": max_tokens, "temperature": 0.3}
    if tools:
        body["tools"] = tools
    last = None
    for attempt in range(3):
        try:
            r = requests.post(url, json=body, headers={"Authorization": f"Bearer {key}"}, timeout=timeout)
        except requests.RequestException as e:
            last = LLMUnavailable(f"network error: {type(e).__name__}")
        else:
            if r.status_code == 401:
                raise LLMAuthError("API key rejected (401)")
            if r.status_code == 402:
                raise LLMUnavailable("insufficient balance (402)")
            if r.status_code == 429 or r.status_code >= 500:
                last = LLMBusy("rate limited / busy") if r.status_code == 429 else LLMUnavailable(f"server error {r.status_code}")
            elif not r.ok:
                raise LLMUnavailable(f"HTTP {r.status_code}")
            else:
                try:
                    return r.json()["choices"][0]
                except (KeyError, IndexError, ValueError, TypeError) as e:
                    raise LLMUnavailable("unexpected response format") from e
        if attempt < 2:
            time.sleep(1.5 * (attempt + 1))
    raise last
