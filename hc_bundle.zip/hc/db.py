"""SQLite persistence: profile, meals, activities, daily stats, weight history."""
import contextvars
import json
import os
import re
import shutil
import sqlite3
from contextlib import closing, contextmanager
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent.parent
_user: contextvars.ContextVar = contextvars.ContextVar("hc_user", default=None)



def data_root() -> Path:
    return Path(os.getenv("HC_DATA_DIR", ROOT / "data"))


def _safe_uid(uid) -> str:
    s = re.sub(r"[^A-Za-z0-9_-]", "", str(uid))
    if not s:
        raise ValueError("invalid user id")
    return s


def user_dir(uid) -> Path:
    return data_root() / "users" / _safe_uid(uid)


def current_user():
    return _user.get()


@contextmanager
def use_user(uid):
    """Scope every db/vector call inside the block to one customer's private folder."""
    token = _user.set(_safe_uid(uid))
    try:
        yield
    finally:
        _user.reset(token)


def list_users() -> list[str]:
    root = data_root() / "users"
    return sorted(p.name for p in root.iterdir() if p.is_dir()) if root.exists() else []


def delete_user_data(uid) -> None:
    shutil.rmtree(user_dir(uid), ignore_errors=True)


def db_path() -> Path:
    u = _user.get()
    if u:
        return user_dir(u) / "health.db"
    return Path(os.getenv("HC_DB_PATH", data_root() / "health.db"))


SCHEMA = """
CREATE TABLE IF NOT EXISTS profile (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  data TEXT NOT NULL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS meals (
  id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, meal_type TEXT NOT NULL,
  item TEXT NOT NULL, quantity_g REAL, kcal REAL NOT NULL, protein REAL DEFAULT 0,
  carbs REAL DEFAULT 0, fat REAL DEFAULT 0, sugar REAL DEFAULT 0,
  source TEXT DEFAULT 'database estimate');
CREATE TABLE IF NOT EXISTS activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, name TEXT NOT NULL,
  minutes REAL NOT NULL, kcal REAL NOT NULL, source TEXT DEFAULT 'MET estimate');
CREATE TABLE IF NOT EXISTS daily (
  day TEXT PRIMARY KEY, water_ml INTEGER DEFAULT 0, steps INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, text TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS custom_foods (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, category TEXT, source TEXT,
  kcal REAL, protein REAL, carbs REAL, fat REAL, sugar REAL, unit_name TEXT, unit_g REAL,
  diet TEXT, dairy INTEGER, allergens TEXT);
CREATE TABLE IF NOT EXISTS chat (
  id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, text TEXT NOT NULL, ts TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS usage (day TEXT PRIMARY KEY, messages INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS weights (
  day TEXT PRIMARY KEY, weight_kg REAL NOT NULL);
"""


def connect() -> sqlite3.Connection:
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def today() -> str:
    return datetime.now(ZoneInfo(os.getenv("HC_TZ", "Asia/Kolkata"))).date().isoformat()


def get_profile() -> dict | None:
    with connect() as c:
        r = c.execute("SELECT data FROM profile WHERE id=1").fetchone()
    return json.loads(r["data"]) if r else None


def save_profile(p: dict) -> None:
    with connect() as c:
        c.execute("INSERT INTO profile(id,data) VALUES(1,?) ON CONFLICT(id) DO UPDATE "
                  "SET data=excluded.data, updated_at=CURRENT_TIMESTAMP", (json.dumps(p),))
        c.execute("INSERT INTO weights(day,weight_kg) VALUES(?,?) "
                  "ON CONFLICT(day) DO UPDATE SET weight_kg=excluded.weight_kg", (today(), p["weight_kg"]))


def add_meal(day, meal_type, item, quantity_g, n: dict, source="database estimate") -> None:
    with connect() as c:
        c.execute("INSERT INTO meals(day,meal_type,item,quantity_g,kcal,protein,carbs,fat,sugar,source) "
                  "VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (day, meal_type, item, quantity_g, n["kcal"], n["protein"], n["carbs"], n["fat"], n["sugar"], source))


def get_meals(day) -> list[dict]:
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM meals WHERE day=? ORDER BY id", (day,))]


def update_meal(meal_id, **vals) -> None:
    allowed = {"item", "quantity_g", "kcal", "protein", "carbs", "fat", "sugar"}
    vals = {k: v for k, v in vals.items() if k in allowed}
    if not vals:
        return
    sets = ", ".join(f"{k}=?" for k in vals)
    with connect() as c:
        c.execute(f"UPDATE meals SET {sets}, source='manually corrected' WHERE id=?", (*vals.values(), meal_id))


def delete_meal(meal_id) -> None:
    with connect() as c:
        c.execute("DELETE FROM meals WHERE id=?", (meal_id,))


def add_activity(day, name, minutes, kcal, source="MET estimate") -> None:
    with connect() as c:
        c.execute("INSERT INTO activities(day,name,minutes,kcal,source) VALUES(?,?,?,?,?)",
                  (day, name, minutes, kcal, source))


def get_activities(day) -> list[dict]:
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM activities WHERE day=? ORDER BY id", (day,))]


def delete_activity(act_id) -> None:
    with connect() as c:
        c.execute("DELETE FROM activities WHERE id=?", (act_id,))


def get_daily(day) -> dict:
    with connect() as c:
        r = c.execute("SELECT * FROM daily WHERE day=?", (day,)).fetchone()
    return dict(r) if r else {"day": day, "water_ml": 0, "steps": 0}


def set_daily(day, water_ml=None, steps=None) -> None:
    cur = get_daily(day)
    water = cur["water_ml"] if water_ml is None else max(0, int(water_ml))
    st = cur["steps"] if steps is None else max(0, int(steps))
    with connect() as c:
        c.execute("INSERT INTO daily(day,water_ml,steps) VALUES(?,?,?) ON CONFLICT(day) DO UPDATE "
                  "SET water_ml=excluded.water_ml, steps=excluded.steps", (day, water, st))


def log_weight(day, kg) -> None:
    with connect() as c:
        c.execute("INSERT INTO weights(day,weight_kg) VALUES(?,?) ON CONFLICT(day) DO UPDATE "
                  "SET weight_kg=excluded.weight_kg", (day, kg))


def get_weights() -> list[dict]:
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM weights ORDER BY day")]


def add_note(kind: str, text: str) -> None:
    with connect() as c:
        c.execute("INSERT INTO notes(kind,text) VALUES(?,?)", (kind, text.strip()))


def get_notes() -> list[dict]:
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM notes ORDER BY id")]


def delete_note(note_id) -> None:
    with connect() as c:
        c.execute("DELETE FROM notes WHERE id=?", (note_id,))


def get_recent_days(limit: int = 30) -> list[str]:
    """Days that have any meals or activities, newest first."""
    with connect() as c:
        rows = c.execute("SELECT day FROM meals UNION SELECT day FROM activities ORDER BY day DESC LIMIT ?", (limit,))
        return [r["day"] for r in rows]


def save_custom_food(f: dict) -> None:
    """Per-100 g values. allergens: list[str]. Re-saving the same name updates it."""
    with connect() as c:
        c.execute("INSERT INTO custom_foods(name,category,source,kcal,protein,carbs,fat,sugar,unit_name,unit_g,diet,dairy,allergens) "
                  "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET category=excluded.category, "
                  "source=excluded.source, kcal=excluded.kcal, protein=excluded.protein, carbs=excluded.carbs, fat=excluded.fat, "
                  "sugar=excluded.sugar, unit_name=excluded.unit_name, unit_g=excluded.unit_g, diet=excluded.diet, "
                  "dairy=excluded.dairy, allergens=excluded.allergens",
                  (f["name"], f.get("category", "My foods"), f.get("source", "manual entry"), f["kcal"], f["protein"], f["carbs"],
                   f["fat"], f["sugar"], f.get("unit_name", "1 serving"), f.get("unit_g", 100), f.get("diet", "unknown"),
                   int(bool(f.get("dairy"))), ";".join(f.get("allergens", []))))


def get_custom_foods() -> list[dict]:
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM custom_foods ORDER BY name")]


def add_chat(role: str, text: str) -> None:
    with connect() as c:
        c.execute("INSERT INTO chat(role,text) VALUES(?,?)", (role, text))


def get_chat(limit: int = 16) -> list[dict]:
    with connect() as c:
        rows = c.execute("SELECT role,text FROM chat ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in reversed(rows)]


def get_setting(key: str, default=None):
    with connect() as c:
        r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def set_setting(key: str, value: str) -> None:
    with connect() as c:
        c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))


def bump_usage(day: str) -> int:
    """Count one agent message for today and return the new total."""
    with connect() as c:
        c.execute("INSERT INTO usage(day,messages) VALUES(?,1) ON CONFLICT(day) DO UPDATE SET messages=messages+1", (day,))
        return c.execute("SELECT messages FROM usage WHERE day=?", (day,)).fetchone()["messages"]


def bump_global_usage(day: str) -> int:
    """Count one agent message across ALL customers today (protects a public demo's API budget)."""
    path = data_root() / "global_usage.db"
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path)) as c:
        c.execute("CREATE TABLE IF NOT EXISTS g(day TEXT PRIMARY KEY, n INTEGER)")
        c.execute("INSERT INTO g(day,n) VALUES(?,1) ON CONFLICT(day) DO UPDATE SET n=n+1", (day,))
        c.commit()
        return c.execute("SELECT n FROM g WHERE day=?", (day,)).fetchone()[0]
