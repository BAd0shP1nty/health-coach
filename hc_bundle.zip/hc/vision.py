"""Photo -> text description, using any OpenAI-compatible vision model (configure VISION_MODEL).
The main DeepSeek agent then reasons over this text, so the vision provider is swappable."""
import os

from . import llm

PROMPT = ("You are helping a nutrition coach. Look at this photo of food. List each food/dish you can see using common Indian names "
          "where applicable. For each give: the name, a rough portion in common units (number of rotis/idlis/pieces, katori, plate, glass) "
          "and approximate grams, and your confidence (high/medium/low). Mention if oil, ghee, sugar, sauces or hidden ingredients "
          "cannot be judged. If there is no food, say exactly: no food visible. Be concise, plain text, no calorie numbers.")


class VisionUnavailable(Exception):
    pass


def available() -> bool:
    return bool(os.getenv("VISION_MODEL", "").strip())


def describe(images: list[dict], caption: str = "") -> str:
    model = os.getenv("VISION_MODEL", "").strip()
    if not model:
        raise VisionUnavailable("VISION_MODEL is not set")
    content = [{"type": "text", "text": PROMPT + (f"\nThe user says: {caption}" if caption else "")}]
    for im in images:
        content.append({"type": "image_url", "image_url": {"url": f"data:{im['media_type']};base64,{im['data']}"}})
    key = os.getenv("VISION_API_KEY") or os.getenv("DEEPSEEK_API_KEY", "")
    try:
        choice = llm.chat([{"role": "user", "content": content}], model=model, base_url=os.getenv("VISION_BASE_URL") or None,
                          api_key=key, max_tokens=600)
    except llm.LLMError as e:
        raise VisionUnavailable(str(e)) from e
    return (choice["message"].get("content") or "").strip()
