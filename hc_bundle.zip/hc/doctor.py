"""Self-check for the Telegram bot setup:  python -m hc.doctor   (or double-click run_doctor.bat)
Tests .env, the Telegram token, the DeepSeek key and the allow-list, and says what to fix."""
import os
import re
import sys
import time

import requests
from dotenv import find_dotenv, load_dotenv

from . import llm

OK, WARN, FAIL = "OK", "WARN", "FAIL"


def mask(v: str) -> str:
    return f"{v[:4]}...{v[-3:]}" if len(v) > 10 else "(very short)"


def check_env() -> list:
    out, path = [], find_dotenv()
    if not path:
        return [(FAIL, ".env file", "Not found. Copy .env.example to .env (exact name, not .env.txt) in the health-coach folder.")]
    out.append((OK, ".env file", f"found at {path}"))
    for key in ("TELEGRAM_BOT_TOKEN", "DEEPSEEK_API_KEY"):
        v = os.getenv(key, "")
        if not v or v.startswith("your_"):
            out.append((FAIL, key, "Missing or still the placeholder. Paste your real value after the = sign."))
        elif v != v.strip() or v[0] in "\"'" or v[-1] in "\"'":
            out.append((WARN, key, "Has spaces or quotes around it. Remove them: KEY=value"))
        else:
            out.append((OK, key, f"set ({mask(v)})"))
    tok = os.getenv("TELEGRAM_BOT_TOKEN", "")
    if tok and not re.fullmatch(r"\d{6,}:[A-Za-z0-9_-]{30,}", tok.strip().strip("\"'")):
        out.append((WARN, "token format", "A Telegram token looks like 123456789:ABCdef... (digits, a colon, then ~35 characters). Re-copy it from BotFather."))
    return out


def check_telegram(get=requests.get) -> list:
    tok = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    if not tok:
        return []
    try:
        r = get(f"https://api.telegram.org/bot{tok}/getMe", timeout=15)
    except requests.RequestException as e:
        return [(FAIL, "Telegram reachable", f"Cannot reach api.telegram.org ({type(e).__name__}). Check internet / VPN / firewall / school or office network.")]
    if r.status_code == 401 or r.status_code == 404:
        return [(FAIL, "Telegram token", "Telegram rejected the token. Copy it again from @BotFather (or /revoke for a new one).")]
    if not r.ok:
        return [(FAIL, "Telegram", f"HTTP {r.status_code} from Telegram.")]
    out = [(OK, "Telegram token", f"valid - your bot is @{r.json()['result']['username']} (message exactly this bot)")]
    try:
        hook = get(f"https://api.telegram.org/bot{tok}/getWebhookInfo", timeout=15).json().get("result", {}).get("url")
        if hook:
            out.append((WARN, "webhook", f"A webhook is set ({hook}); it blocks polling. Open https://api.telegram.org/bot<TOKEN>/deleteWebhook once."))
    except (requests.RequestException, ValueError):
        pass
    return out


def check_deepseek(chat=llm.chat) -> list:
    if not llm.configured():
        return []
    t0 = time.time()
    try:
        chat([{"role": "user", "content": "Reply with the single word OK"}], max_tokens=5, timeout=30)
    except llm.LLMAuthError:
        return [(FAIL, "DeepSeek key", "Rejected (401). Create a new key on platform.deepseek.com and paste it into .env.")]
    except llm.LLMBusy:
        return [(WARN, "DeepSeek", "Rate limited (429). Wait a minute, or check your account limits.")]
    except llm.LLMError as e:
        return [(FAIL, "DeepSeek", f"{e}. If this says 'insufficient balance', top up the account; otherwise check your internet.")]
    return [(OK, "DeepSeek key", f"works ({time.time() - t0:.1f}s)")]


def check_allowlist() -> list:
    ids = [i.strip() for i in os.getenv("TELEGRAM_ALLOWED_IDS", "").split(",") if i.strip()]
    if not ids:
        return [(OK, "allow-list", "not set - anyone who finds the bot can use it")]
    bad = [i for i in ids if not i.isdigit()]
    msg = f"only these Telegram user IDs may chat: {', '.join(ids)}. "
    if bad:
        return [(FAIL, "allow-list", msg + f"{bad} are not numbers.")]
    return [(WARN, "allow-list", msg + "If the bot ignores you, your ID is not in this list - the bot will tell you your real ID, "
                                  "or put a # in front of this line to turn the list off. (The number in Telegram Web's address bar is NOT your ID.)")]


def check_deps() -> list:
    out = []
    for mod, required, note in (("telegram", True, ""), ("PIL", True, ""),
                                ("chromadb", False, "personal-memory search is off without it"),
                                ("faster_whisper", False, "voice notes are off without it")):
        try:
            __import__(mod)
            out.append((OK, f"package {mod}", "installed"))
        except ImportError:
            fix = "run run_bot.bat again (it installs packages)" if required else f"optional: {note}. Install with: pip install -r requirements-extra.txt"
            out.append((FAIL if required else WARN, f"package {mod}", f"missing - {fix}"))
    return out


def run_all() -> list:
    load_dotenv()
    return check_env() + check_deps() + check_telegram() + check_deepseek() + check_allowlist()


def main() -> int:
    results = run_all()
    for status, title, detail in results:
        print(f"[{status:4}] {title}: {detail}")
    fails = [r for r in results if r[0] == FAIL]
    print()
    if fails:
        print(f"{len(fails)} problem(s) found - fix the [FAIL] lines above, then run the bot again.")
    else:
        print("Setup looks good. Start the bot (run_bot.bat), message it, and watch its window: you should see a line like\n"
              "'incoming text from user id 123'. If you see that but get no reply, copy the lines around it and send them to me.\n"
              "If you never see it, you are messaging a different bot, or another copy of the bot is already running.")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
