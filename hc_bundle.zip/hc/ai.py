"""DeepSeek integration. Only generates advice; all targets come from hc.calc."""
import json
import os

import requests
from dotenv import load_dotenv

from .foods import allergy_tokens

load_dotenv()


class AIUnavailable(Exception):
    """Raised for any problem reaching/understanding the AI service (UI shows a friendly message)."""


SYSTEM = (
    "You are a careful nutrition-education assistant for Indian diets. Suggest practical Indian "
    "home-style meals. Respect the user's diet, allergies and medical conditions strictly. Never recommend "
    "starvation, crash diets, skipping meals to cut calories, or unsafe exercise. Do not give medical "
    "advice or medication guidance; for medical conditions say to follow their doctor/dietitian. "
    "Nutrition numbers are rough ESTIMATES - round them, never claim precision. "
    "You are given retrieved CUSTOMER MEMORY (notes, history) and REFERENCE FOODS. Use memory to personalise: honour stated "
    "dislikes/routines, avoid repeating very recent meals, follow doctor notes. Prefer reference foods and their per-100 g values "
    "when building meals. Memory never overrides the profile's diet/allergy/medical limits, and never invent facts about the user. "
    "Reply with ONLY valid JSON, no markdown."
)

MEAL_SCHEMA = (
    '{"meals":[{"meal_type":"Breakfast|Lunch|Snack|Dinner","name":"...","why":"one sentence",'
    '"ingredients":[{"item":"...","quantity":"e.g. 100 g / 1 katori"}],"steps":["..."],'
    '"estimated_nutrition":{"kcal":0,"protein_g":0,"carbs_g":0,"fat_g":0,"sugar_g":0}}],'
    '"notes":"optional short safety/tip note"}'
)


def _context(profile: dict, targets, remaining: dict) -> str:
    return (
        f"User: {profile['age']}y {profile['sex']}, goal: {profile['goal']}, diet: {profile['diet']}.\n"
        f"Allergies: {profile.get('allergies') or 'none'}.\n"
        f"Medical conditions: {', '.join(profile.get('conditions') or []) or 'none'}"
        f"{('; ' + profile['other_conditions']) if profile.get('other_conditions') else ''}.\n"
        f"Daily targets: {targets.calories} kcal, protein {targets.protein_g} g, carbs {targets.carbs_g} g, "
        f"fat {targets.fat_g} g, sugar <= {targets.sugar_g} g.\n"
        f"Remaining today: {remaining['kcal']:.0f} kcal, protein {remaining['protein']:.0f} g, "
        f"carbs {remaining['carbs']:.0f} g, fat {remaining['fat']:.0f} g, sugar {remaining['sugar']:.0f} g."
    )


def _retrieved(context: dict | None) -> str:
    if not context or not (context.get("memory") or context.get("foods")):
        return ""
    mem = "\n".join(f"- [{m['kind']}] {m['text']}" for m in context.get("memory", [])) or "- (none)"
    fds = "\n".join(f"- {t}" for t in context.get("foods", [])) or "- (none)"
    return f"\n\nCUSTOMER MEMORY (retrieved, most relevant first):\n{mem}\n\nREFERENCE FOODS (approximate values, already filtered for diet/allergies):\n{fds}"


def build_prompt(mode: str, profile, targets, remaining, extra: dict | None = None, context: dict | None = None) -> str:
    extra = extra or {}
    ctx = _context(profile, targets, remaining) + _retrieved(context)
    if mode == "next_meal":
        task = (f"Recommend 3 options for the user's NEXT meal ({extra.get('meal_type', 'any meal')}) that fit within "
                "the remaining calories and macros (do not exceed remaining kcal). Include recipe, quantities, steps.")
    elif mode == "substitute":
        task = (f"The user wants to replace this meal/ingredient: '{extra.get('original', '')}'. "
                f"Reason: {extra.get('reason') or 'preference'}. Suggest 3 substitutes with similar calories/protein "
                "that respect the diet, allergies and conditions.")
    elif mode == "daily_plan":
        task = ("Create a full-day Indian meal plan (Breakfast, Lunch, Snack, Dinner) totalling close to the daily "
                f"targets (within ~5%). Foods already eaten today: {extra.get('eaten') or 'nothing'}.")
    else:
        raise ValueError(f"unknown mode {mode}")
    return f"{ctx}\n\nTask: {task}\n\nReturn JSON in exactly this shape:\n{MEAL_SCHEMA}"


def call_deepseek(prompt: str, timeout: int = 90) -> dict:
    key = os.getenv("DEEPSEEK_API_KEY", "").strip()
    if not key or key.startswith("your_"):
        raise AIUnavailable("No DeepSeek API key found. Add DEEPSEEK_API_KEY to your .env file.")
    base = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/")
    body = {
        "model": os.getenv("DEEPSEEK_MODEL", "deepseek-chat"),
        "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}],
        "response_format": {"type": "json_object"},
        "temperature": 0.5,
        "max_tokens": 3500,
    }
    try:
        r = requests.post(f"{base}/chat/completions", json=body, timeout=timeout,
                          headers={"Authorization": f"Bearer {key}"})
    except requests.RequestException as e:
        raise AIUnavailable(f"Could not reach DeepSeek ({type(e).__name__}). Check your internet connection.") from e
    msgs = {401: "DeepSeek rejected the API key (401). Check DEEPSEEK_API_KEY in .env.",
            402: "DeepSeek account has insufficient balance (402).",
            429: "DeepSeek rate limit reached (429). Try again shortly."}
    if r.status_code in msgs:
        raise AIUnavailable(msgs[r.status_code])
    if not r.ok:
        raise AIUnavailable(f"DeepSeek returned an error (HTTP {r.status_code}).")
    try:
        return parse_response(r.json()["choices"][0]["message"]["content"])
    except (KeyError, IndexError, ValueError, TypeError) as e:
        raise AIUnavailable("DeepSeek returned an unexpected response. Please try again.") from e


def parse_response(content: str) -> dict:
    content = content.strip()
    if content.startswith("```"):
        content = content.strip("`").removeprefix("json").strip()
    data = json.loads(content)
    if not isinstance(data.get("meals"), list) or not data["meals"]:
        raise ValueError("no meals in response")
    return data


def allergy_warnings(data: dict, allergies: str) -> list[str]:
    """Second line of defence: flag any suggested ingredient that matches a declared allergy."""
    toks = allergy_tokens(allergies)
    out = []
    for m in data["meals"]:
        for ing in m.get("ingredients", []):
            name = str(ing.get("item", "")).lower()
            for t in toks:
                if t in name:
                    out.append(f"'{m.get('name')}' contains '{ing.get('item')}' which may match your allergy '{t}'.")
    return out


def recommend(mode, profile, targets, remaining, extra=None, context=None) -> dict:
    return call_deepseek(build_prompt(mode, profile, targets, remaining, extra, context))
