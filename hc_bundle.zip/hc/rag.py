"""Retrieval-augmented context. A local Chroma vector DB holds:
  - customer_memory: this user's profile, notes, daily meal/activity history, weight trend
  - food_knowledge:  the reference Indian food table (so the LLM can ground nutrition on it)
SQLite stays the source of truth; the vector index is re-synced from it before each AI call.
The LLM reasons over what is retrieved; hard constraints (diet, allergies) are enforced in code.
"""
import os
from functools import lru_cache
from pathlib import Path

from . import calc, db, foods

USER_ID = "default"  # single local customer; metadata filter keeps room for more


@lru_cache(maxsize=4)
def _client(path: str):
    import chromadb  # heavy optional dependency: imported lazily so the bot still runs without it
    from chromadb.config import Settings
    return chromadb.PersistentClient(path=path, settings=Settings(anonymized_telemetry=False))


def _col(name: str):
    u = db.current_user()
    path = str(db.user_dir(u) / "vectordb") if u else os.getenv("HC_VECTOR_PATH", str(db.data_root() / "vectordb"))
    return _client(path).get_or_create_collection(name, metadata={"hnsw:space": "cosine"})


# ---------------------------------------------------------------- customer memory
def _profile_doc(p: dict, t: calc.Targets) -> str:
    return (f"Profile: {p['age']}y {p['sex']}, {p['height_cm']:.0f} cm, {p['weight_kg']:.1f} kg, target {p['target_weight_kg']:.1f} kg "
            f"in {p['timeline_weeks']} weeks. Goal {p['goal']}. Diet {p['diet']}. Allergies: {p.get('allergies') or 'none'}. "
            f"Conditions: {', '.join(p.get('conditions') or []) or 'none'} {p.get('other_conditions') or ''}. "
            f"Targets {t.calories} kcal, protein {t.protein_g} g.")


def _day_doc(day: str) -> str:
    meals, acts, daily = db.get_meals(day), db.get_activities(day), db.get_daily(day)
    parts = []
    for mt in ("Breakfast", "Lunch", "Snack", "Dinner"):
        items = [f"{m['item']} ({m['kcal']:.0f} kcal)" for m in meals if m["meal_type"] == mt]
        if items:
            parts.append(f"{mt}: " + ", ".join(items))
    n = calc.sum_nutrition(meals)
    text = f"On {day} the customer ate - " + "; ".join(parts) if parts else f"On {day} no meals logged"
    text += f". Totals {n['kcal']:.0f} kcal, protein {n['protein']:.0f} g, carbs {n['carbs']:.0f} g, fat {n['fat']:.0f} g, sugar {n['sugar']:.0f} g."
    if acts:
        text += " Exercise: " + ", ".join(f"{a['name']} {a['minutes']:.0f} min" for a in acts) + "."
    if daily["water_ml"] or daily["steps"]:
        text += f" Water {daily['water_ml']} ml, steps {daily['steps']}."
    return text


def build_memory_docs(profile: dict, targets: calc.Targets) -> dict[str, tuple[str, dict]]:
    docs = {"profile": (_profile_doc(profile, targets), {"kind": "profile"})}
    for n in db.get_notes():
        docs[f"note-{n['id']}"] = (f"{n['kind']}: {n['text']}", {"kind": "note"})
    for day in db.get_recent_days(30):
        docs[f"day-{day}"] = (_day_doc(day), {"kind": "history"})
    ws = db.get_weights()[-8:]
    if len(ws) > 1:
        docs["weights"] = ("Weight trend: " + ", ".join(f"{w['day']} {w['weight_kg']:.1f} kg" for w in ws), {"kind": "weight"})
    return docs


def sync_memory(profile: dict, targets: calc.Targets) -> None:
    """Upsert changed docs and delete stale ones so the index mirrors SQLite."""
    col = _col("customer_memory")
    docs = build_memory_docs(profile, targets)
    ex = col.get(where={"user_id": USER_ID}, include=["documents"])
    existing = dict(zip(ex["ids"], ex["documents"]))
    stale = [i for i in existing if i not in docs]
    if stale:
        col.delete(ids=stale)
    changed = [i for i, (txt, _) in docs.items() if existing.get(i) != txt]
    if changed:
        col.upsert(ids=changed, documents=[docs[i][0] for i in changed],
                   metadatas=[{**docs[i][1], "user_id": USER_ID} for i in changed])


def retrieve_memory(query: str, kinds: tuple[str, ...], n: int = 5) -> list[dict]:
    col = _col("customer_memory")
    where = {"$and": [{"user_id": USER_ID}, {"kind": {"$in": list(kinds)}}]}
    total = len(col.get(where=where)["ids"])
    if not total:
        return []
    r = col.query(query_texts=[query], n_results=min(n, total), where=where)
    return [{"text": d, "kind": m["kind"], "distance": round(x, 3)}
            for d, m, x in zip(r["documents"][0], r["metadatas"][0], r["distances"][0])]


# ---------------------------------------------------------------- food knowledge
def _food_doc(f: dict) -> str:
    return (f"{f['name']} ({f['category']}): per 100 g {f['kcal']:.0f} kcal, protein {f['protein']:g} g, carbs {f['carbs']:g} g, "
            f"fat {f['fat']:g} g, sugar {f['sugar']:g} g. Serving {f['unit_name']} = {f['unit_g']:.0f} g. "
            f"Diet: {f['diet']}. Allergens: {', '.join(f['allergens']) or 'none'}.")


def sync_foods() -> None:
    col = _col("food_knowledge")
    fl = foods.load_foods()
    if col.count() == len(fl):
        return
    col.upsert(ids=[f"food-{i}" for i in range(len(fl))], documents=[_food_doc(f) for f in fl],
               metadatas=[{"name": f["name"]} for f in fl])


def search_foods(query: str, n: int = 6) -> list[dict]:
    """Candidates for the agent to choose from: lexical (names/synonyms) first, then semantic. No diet filter."""
    fl = foods.load_foods()
    by_name = {f["name"]: f for f in fl}
    names = [f["name"] for f in foods.lexical_search(query, fl, 4)]
    try:
        sync_foods()
        col = _col("food_knowledge")
        r = col.query(query_texts=[query], n_results=min(col.count(), 4))
        names += [m["name"] for m in r["metadatas"][0]]
    except Exception:  # noqa: BLE001 - lexical results are still useful offline
        pass
    seen, out = set(), []
    for nm in names:
        if nm not in seen and nm in by_name:
            seen.add(nm)
            out.append(by_name[nm])
    return out[:n]


def retrieve_foods(query: str, profile: dict, n: int = 8) -> list[str]:
    sync_foods()
    col = _col("food_knowledge")
    r = col.query(query_texts=[query], n_results=min(col.count(), n * 4))
    by_name = {f["name"]: f for f in foods.load_foods()}
    out = []
    for meta, doc in zip(r["metadatas"][0], r["documents"][0]):
        f = by_name[meta["name"]]
        if foods.diet_ok(f, profile["diet"]) and not foods.allergy_hit(f, profile.get("allergies", "")):
            out.append(doc)
        if len(out) == n:
            break
    return out


# ---------------------------------------------------------------- public entry
def get_context(profile: dict, targets: calc.Targets, remaining: dict, task_text: str) -> dict:
    """Never raises: on any failure the AI call proceeds without retrieved context."""
    try:
        sync_memory(profile, targets)
        hints = []
        if remaining["protein"] > 25:
            hints.append("high protein")
        if remaining["kcal"] < 350:
            hints.append("light low calorie")
        q_food = f"{task_text} Indian {profile['diet']} {' '.join(hints)}"
        # Notes are few and high-value (ranked, up to 6); history/weight give recency context (top 3).
        memory = retrieve_memory(task_text, ("note",), 6) + retrieve_memory(task_text, ("history", "weight"), 3)
        return {"memory": memory, "foods": retrieve_foods(q_food, profile), "error": None}
    except Exception as e:  # noqa: BLE001 - embedding download/offline/etc.
        return {"memory": [], "foods": [], "error": f"{type(e).__name__}: {e}"}
