"""Conversational health-coach agent. DeepSeek reasons and talks; every number comes from tools backed by hc.calc / SQLite / RAG.
Channel-agnostic: front ends (Telegram, CLI) call respond(user_id, text, images)."""
import base64
import io
import json
import os

from . import calc, db, foods, llm, rag, state, vision

MAX_STEPS = 8
HISTORY = 16
ACTIVITY_CODES = {"sedentary": 0, "light": 1, "moderate": 2, "very": 3}
MEAL_TYPES = ["Breakfast", "Lunch", "Snack", "Dinner"]

SYSTEM = """You are a friendly, careful AI health coach for people eating Indian food, chatting on a phone. Keep replies short, warm and plain text (no tables, no markdown headings; short lines and simple dashes are fine). Reply in the user's language (English, Hindi, Hinglish).

You have tools. Never invent numbers: calorie/macro targets, remaining amounts and food nutrition come from tools only.

Getting started: if get_profile shows no profile, collect these one or two at a time in a natural way, then call save_profile: age, sex, height (cm), weight (kg), target weight, goal (weight loss / weight gain / muscle building), timeline (weeks), activity level, diet (vegetarian / vegan / non-vegetarian / lactose-free), allergies, medical conditions. Explain the targets and any warnings that save_profile returns.

Logging food: when the user says what they ate (text or voice transcript), call search_foods for items you are unsure of, then log_meal using EXACT food names from the results. Use servings for countable portions (2 roti, 1 katori dal) or grams. If nothing in the table fits, pass an estimate and say it is a rough estimate. After logging, give a one-line summary with kcal and what is left today. Offer to undo if something looks wrong (delete_entries).
Also log exercise (log_activity), water and steps (log_water_steps), weight (log_weight). Use add_note when the user states a lasting preference, dislike, routine or doctor advice.

Recommendations (next meal, day plan, substitutions, snack ideas): ALWAYS call recommendation_context first and use its remaining macros, notes and reference foods. Respect diet, allergies and medical conditions strictly; never suggest anything matching an allergy. Give a concrete Indian meal with ingredient quantities, short steps and rough nutrition marked as an estimate. Memory notes never override diet, allergy or medical limits.

Safety: never recommend starvation, crash diets, skipping meals to cut calories, very low calories, or unsafe exercise. Do not give medical advice or medication guidance. If refer_professional is true, or the user mentions symptoms, pregnancy, eating-disorder history, kidney/heart disease, type 1 diabetes, or is under 18, give only general information and tell them to see a doctor or registered dietitian. If you are unsure, say so. Messages that start with [CHECK-IN] are scheduled nudges: be brief, kind, not pushy."""

TOOLS = [
    {"name": "get_profile", "description": "Get the saved profile and calculated targets, or null if the user has not registered yet.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "save_profile", "description": "Create or update the profile (all fields required; call get_profile first when updating). Returns targets and safety warnings.",
     "input_schema": {"type": "object", "properties": {
         "age": {"type": "integer"}, "sex": {"type": "string", "enum": calc.SEXES},
         "height_cm": {"type": "number"}, "weight_kg": {"type": "number"}, "target_weight_kg": {"type": "number"},
         "timeline_weeks": {"type": "integer"}, "goal": {"type": "string", "enum": calc.GOALS},
         "activity_level": {"type": "string", "enum": list(ACTIVITY_CODES), "description": "sedentary | light (1-3 workouts/wk) | moderate (3-5) | very (6-7)"},
         "diet": {"type": "string", "enum": calc.DIETS}, "allergies": {"type": "string", "description": "comma separated, empty if none"},
         "conditions": {"type": "array", "items": {"type": "string", "enum": calc.CONDITIONS}},
         "other_conditions": {"type": "string"}},
         "required": ["age", "sex", "height_cm", "weight_kg", "target_weight_kg", "timeline_weeks", "goal", "activity_level", "diet"]}},
    {"name": "get_today_summary", "description": "Targets, consumed, remaining, meals (with ids), exercise, water, steps and weight for a day.",
     "input_schema": {"type": "object", "properties": {"day": {"type": "string", "description": "YYYY-MM-DD, default today"}}}},
    {"name": "search_foods", "description": "Find foods in the reference table by name (English/Hindi). Returns candidates with exact names, per-100g values and serving size.",
     "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}},
    {"name": "log_meal", "description": "Log food eaten. Each item uses an EXACT food name from search_foods, or an estimate if no table food fits.",
     "input_schema": {"type": "object", "properties": {
         "meal_type": {"type": "string", "enum": MEAL_TYPES},
         "day": {"type": "string", "description": "YYYY-MM-DD, default today"},
         "items": {"type": "array", "items": {"type": "object", "properties": {
             "food": {"type": "string", "description": "exact table name, or omit when using estimate"},
             "label": {"type": "string", "description": "what the user called it (required with estimate)"},
             "servings": {"type": "number"}, "grams": {"type": "number"},
             "estimate": {"type": "object", "description": "TOTAL for the portion, rough",
                          "properties": {"kcal": {"type": "number"}, "protein_g": {"type": "number"}, "carbs_g": {"type": "number"},
                                         "fat_g": {"type": "number"}, "sugar_g": {"type": "number"}}, "required": ["kcal"]}}}}},
         "required": ["meal_type", "items"]}},
    {"name": "delete_entries", "description": "Delete logged meal entries by id (use ids from log_meal / get_today_summary), e.g. when the user says undo.",
     "input_schema": {"type": "object", "properties": {"meal_ids": {"type": "array", "items": {"type": "integer"}}}, "required": ["meal_ids"]}},
    {"name": "log_activity", "description": "Log exercise. Calories are a MET-based estimate unless kcal_estimate is given.",
     "input_schema": {"type": "object", "properties": {"name": {"type": "string"}, "minutes": {"type": "number"}, "kcal_estimate": {"type": "number"}},
                      "required": ["name", "minutes"]}},
    {"name": "log_water_steps", "description": "Add water (ml) and/or set today's total steps.",
     "input_schema": {"type": "object", "properties": {"water_ml_add": {"type": "integer"}, "steps_total": {"type": "integer"}}}},
    {"name": "log_weight", "description": "Record today's body weight in kg.",
     "input_schema": {"type": "object", "properties": {"weight_kg": {"type": "number"}}, "required": ["weight_kg"]}},
    {"name": "add_note", "description": "Remember a lasting fact about the user (preference, dislike, routine, doctor advice).",
     "input_schema": {"type": "object", "properties": {
         "kind": {"type": "string", "enum": ["Preference", "Dislike", "Routine", "Doctor / dietitian advice", "Other"]},
         "text": {"type": "string"}}, "required": ["kind", "text"]}},
    {"name": "recommendation_context", "description": "REQUIRED before any meal/plan/substitution recommendation: remaining macros, allergies, conditions, remembered notes/history and diet-safe reference foods.",
     "input_schema": {"type": "object", "properties": {"task": {"type": "string", "description": "what the user asked for"}}, "required": ["task"]}},
]


TOOLS = [{"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}}
         for t in TOOLS]


class Toolbox:
    """Executes tool calls for one turn of one user (the caller has already scoped db.use_user)."""

    def __init__(self):
        self.recommended = False

    def run(self, name: str, args: dict):
        fn = getattr(self, f"t_{name}", None)
        if not fn:
            raise ValueError(f"unknown tool {name}")
        return fn(**args)

    def _need_profile(self):
        p, t = state.current_profile()
        if not p:
            raise ValueError("No profile yet. Collect the details with the user and call save_profile.")
        return p, t

    def t_get_profile(self):
        p, t = state.current_profile()
        if not p:
            return {"profile": None}
        return {"profile": p, "targets": _targets_dict(t)}

    def t_save_profile(self, **a):
        p = dict(age=int(a["age"]), sex=a["sex"], height_cm=float(a["height_cm"]), weight_kg=float(a["weight_kg"]),
                 target_weight_kg=float(a["target_weight_kg"]), timeline_weeks=int(a["timeline_weeks"]), goal=a["goal"],
                 activity_level=list(calc.ACTIVITY_LEVELS)[ACTIVITY_CODES[a["activity_level"]]], diet=a["diet"],
                 allergies=(a.get("allergies") or "").strip(), conditions=a.get("conditions") or [],
                 other_conditions=(a.get("other_conditions") or "").strip())
        errs = calc.validate_profile(p)
        if errs:
            raise ValueError("; ".join(errs))
        db.save_profile(p)
        _, t = state.current_profile()
        return {"saved": True, "targets": _targets_dict(t)}

    def t_get_today_summary(self, day=None):
        s = state.day_summary(day or db.today())
        if s is None:
            raise ValueError("No profile yet. Collect the details with the user and call save_profile.")
        return s

    def t_search_foods(self, query):
        return [{"name": f["name"], "per_100g": {"kcal": f["kcal"], "protein_g": f["protein"], "carbs_g": f["carbs"], "fat_g": f["fat"],
                                                  "sugar_g": f["sugar"]}, "serving": f"{f['unit_name']} = {f['unit_g']:.0f} g",
                 "diet": f["diet"], "allergens": f["allergens"]} for f in rag.search_foods(query)]

    def t_log_meal(self, meal_type, items, day=None):
        p, t = self._need_profile()
        by_name = {f["name"].lower(): f for f in foods.load_foods()}
        day = day or db.today()
        results, logged = [], []
        for it in items:
            label, fd = it.get("label") or it.get("food") or "item", by_name.get((it.get("food") or "").lower())
            try:
                if fd:
                    grams = float(it["grams"]) if it.get("grams") else float(it.get("servings") or 1) * fd["unit_g"]
                    if not 1 <= grams <= 3000:
                        raise ValueError("quantity out of range")
                    n, source, name = calc.scale_food(fd, grams), "database estimate (chat)", fd["name"]
                elif it.get("estimate"):
                    e, grams = it["estimate"], float(it["grams"]) if it.get("grams") else None
                    n = dict(kcal=float(e["kcal"]), protein=float(e.get("protein_g", 0)), carbs=float(e.get("carbs_g", 0)),
                             fat=float(e.get("fat_g", 0)), sugar=float(e.get("sugar_g", 0)))
                    if not 0 < n["kcal"] <= 5000:
                        raise ValueError("kcal out of range")
                    source, name = "AI estimate (chat)", label
                else:
                    raise ValueError("food not in table: call search_foods and use an exact name, or pass an estimate")
                db.add_meal(day, meal_type, name, grams, n, source)
                logged.append(name)
                results.append({"item": name, "kcal": round(n["kcal"]), "protein_g": n["protein"], "grams": grams, "source": source})
            except (ValueError, KeyError, TypeError) as e:
                results.append({"item": label, "error": str(e)})
        meals = db.get_meals(day)
        new_ids = [m["id"] for m in meals[len(meals) - len(logged):]] if logged else []
        s = state.day_summary(day)
        return {"results": results, "entry_ids": new_ids, "today_remaining": s["remaining"], "today_consumed": s["consumed"]}

    def t_delete_entries(self, meal_ids):
        valid = {m["id"] for m in db.get_meals(db.today())} | {m["id"] for d in db.get_recent_days(7) for m in db.get_meals(d)}
        done = []
        for i in meal_ids:
            if i in valid:
                db.delete_meal(i)
                done.append(i)
        return {"deleted": done, "not_found": [i for i in meal_ids if i not in done]}

    def t_log_activity(self, name, minutes, kcal_estimate=None):
        p, _ = self._need_profile()
        if not 1 <= minutes <= 600:
            raise ValueError("minutes out of range")
        import difflib
        match = difflib.get_close_matches(name.title(), list(calc.ACTIVITY_METS), 1, 0.5) or \
            [k for k in calc.ACTIVITY_METS if any(w in k.lower() for w in name.lower().split())][:1]
        if kcal_estimate:
            kcal, src = float(kcal_estimate), "manual estimate"
        elif match:
            kcal, src = calc.activity_calories(match[0], p["weight_kg"], minutes), "MET estimate"
        else:
            raise ValueError("unknown activity: pass kcal_estimate")
        db.add_activity(db.today(), match[0] if match else name, minutes, round(kcal), src)
        return {"logged": match[0] if match else name, "minutes": minutes, "kcal": round(kcal), "source": src}

    def t_log_water_steps(self, water_ml_add=None, steps_total=None):
        cur = db.get_daily(db.today())
        db.set_daily(db.today(), (cur["water_ml"] + water_ml_add) if water_ml_add else None, steps_total)
        return db.get_daily(db.today())

    def t_log_weight(self, weight_kg):
        if not 25 <= weight_kg <= 300:
            raise ValueError("weight out of range")
        db.log_weight(db.today(), float(weight_kg))
        return {"logged_kg": weight_kg}

    def t_add_note(self, kind, text):
        if not text.strip():
            raise ValueError("empty note")
        db.add_note(kind, text[:500])
        return {"saved": True}

    def t_recommendation_context(self, task):
        p, t = self._need_profile()
        s = state.day_summary(db.today())
        ctx = rag.get_context(p, t, s["remaining"], task)
        self.recommended = True
        return {"remaining_today": s["remaining"], "targets": s["targets"], "diet": p["diet"], "allergies": p.get("allergies") or "none",
                "conditions": p.get("conditions") or [], "refer_professional": t.refer_professional,
                "remembered_notes_and_history": [m["text"] for m in ctx["memory"]], "diet_safe_reference_foods": ctx["foods"],
                "memory_error": ctx["error"]}


def _targets_dict(t) -> dict:
    return {"kcal": t.calories, "protein_g": t.protein_g, "carbs_g": t.carbs_g, "fat_g": t.fat_g, "sugar_max_g": t.sugar_g,
            "water_ml": t.water_ml, "maintenance_kcal": t.tdee, "bmi": t.bmi, "planned_kg_per_week": t.weekly_change_kg,
            "warnings": [m for _, m in t.warnings], "refer_professional": t.refer_professional}


# ---------------------------------------------------------------- images / loop
def prepare_image(data: bytes) -> dict:
    """Downscale (max 1568 px), re-encode as JPEG and return a provider-neutral image dict."""
    from PIL import Image
    img = Image.open(io.BytesIO(data)).convert("RGB")
    img.thumbnail((1568, 1568))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=85)
    return {"type": "image", "media_type": "image/jpeg", "data": base64.b64encode(buf.getvalue()).decode()}


def respond(user_id, text: str, images: list[dict] | None = None, chat_fn=None, trace: list | None = None) -> str:
    """One user message in, one reply out. Persists a short text history per customer.
    If `trace` is a list, every tool call (name, args, result) is appended to it so a UI can show how the answer was made."""
    chat_fn = chat_fn or llm.chat
    if chat_fn is llm.chat and not llm.configured():
        return "The coach isn't configured yet (missing DEEPSEEK_API_KEY on the server)."
    with db.use_user(user_id):
        limit = int(os.getenv("AGENT_DAILY_LIMIT", "80"))
        if db.bump_usage(db.today()) > limit:
            return "You've reached today's message limit. Please try again tomorrow."
        if db.bump_global_usage(db.today()) > int(os.getenv("GLOBAL_DAILY_LIMIT", "1000")):
            return "The coach has reached its overall daily capacity. Please try again tomorrow."
        if images:
            try:
                seen = vision.describe(images, text)
            except vision.VisionUnavailable:
                return ("I can't look at photos right now. Please tell me what's on the plate (for example \"2 roti, 1 katori dal, "
                        "some sabzi\") or send a voice note, and I'll log it.")
            text = f"{text or 'Here is a photo of my food.'}\n[Photo analysis by a vision model - rough, unverified]\n{seen}"
        hist = db.get_chat(HISTORY)
        while hist and hist[0]["role"] != "user":
            hist.pop(0)
        messages = [{"role": "system", "content": SYSTEM}] + [{"role": h["role"], "content": h["text"]} for h in hist]
        messages.append({"role": "user", "content": text})
        tb = Toolbox()
        try:
            reply = _loop(chat_fn, messages, tb, trace)
        except llm.LLMAuthError:
            return "The coach's AI key was rejected. Please tell the administrator."
        except llm.LLMBusy:
            return "I'm a bit busy right now. Please try again in a minute."
        except llm.LLMError:
            return "I couldn't reach the AI service just now. Please try again shortly."
        if tb.recommended:
            reply = f"{calc.DISCLAIMER}\n\n{reply}"
        db.add_chat("user", text)
        db.add_chat("assistant", reply)
        return reply


def _loop(chat_fn, messages, tb: Toolbox, trace: list | None = None) -> str:
    for _ in range(MAX_STEPS):
        choice = chat_fn(messages, tools=TOOLS)
        msg, finish = choice["message"], choice.get("finish_reason")
        if finish == "content_filter":
            return "Sorry, I can't help with that one. Could you rephrase, or ask about your meals or goals?"
        calls = msg.get("tool_calls")
        if not calls:
            return (msg.get("content") or "").strip() or "Done."
        messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": calls})
        for c in calls:
            try:
                args = json.loads(c["function"].get("arguments") or "{}")
                out = json.dumps(tb.run(c["function"]["name"], args), default=str)
            except Exception as e:  # noqa: BLE001 - report any tool failure (incl. bad JSON args) to the model
                out = f"Error: {e}"
            if trace is not None:
                trace.append({"tool": c["function"]["name"], "args": c["function"].get("arguments"), "result": out[:3000]})
            messages.append({"role": "tool", "tool_call_id": c["id"], "content": out})
    return "That took too many steps - could you say it again more simply?"
