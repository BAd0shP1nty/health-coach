"""Sample food reference data (approximate, per 100 g of food as eaten)."""
import csv
import difflib
import re
from pathlib import Path

FOODS_CSV = Path(__file__).resolve().parent.parent / "data" / "foods.csv"
NUM = ("kcal", "protein", "carbs", "fat", "sugar", "unit_g")


REF_SOURCE = "Reference table (approximate; IFCT 2017 / USDA typical values, rounded)"


def load_foods() -> list[dict]:
    """Bundled reference table + the user's saved packaged/custom foods (per 100 g)."""
    from . import db  # local import: db has no dependency on foods
    with open(FOODS_CSV, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for k in NUM:
            r[k] = float(r[k])
        r["dairy"] = r["dairy"] == "1"
        r["allergens"] = [a.strip().lower() for a in r["allergens"].split(";") if a.strip()]
        r["source"] = REF_SOURCE
    names = {r["name"] for r in rows}
    for c in db.get_custom_foods():
        if c["name"] in names:
            continue
        c["dairy"] = bool(c["dairy"])
        c["allergens"] = [a for a in (c["allergens"] or "").split(";") if a]
        rows.append(c)
    return rows


SYNONYMS = {"chapati": "roti", "chapatti": "roti", "phulka": "roti", "chawal": "rice", "dahi": "curd", "sabji": "sabzi",
            "subji": "sabzi", "aloo": "potato", "gobi": "cauliflower", "bhaji": "sabzi", "curd": "dahi", "anda": "egg",
            "murgh": "chicken", "machli": "fish", "doodh": "milk", "chai": "tea", "namkeen": "bhujia", "atta": "wheat"}


def _tokens(s: str) -> set[str]:
    out = set()
    for t in re.findall(r"[a-z]+", s.lower()):
        t = t[:-1] if len(t) > 3 and t.endswith("s") else t
        out.add(t)
        if t in SYNONYMS:
            out.add(SYNONYMS[t])
    return out


def lexical_search(query: str, food_list: list[dict], n: int = 5) -> list[dict]:
    """Rank foods by shared words (with Hindi/English synonyms) plus fuzzy similarity."""
    q = _tokens(query)
    scored = []
    for f in food_list:
        t = _tokens(f["name"])
        overlap = len(q & t)
        sim = difflib.SequenceMatcher(None, query.lower(), f["name"].lower()).ratio()
        if overlap or sim > 0.6:
            scored.append((overlap + sim, f))
    scored.sort(key=lambda x: -x[0])
    return [f for _, f in scored[:n]]


def diet_ok(food: dict, diet: str) -> bool:
    if diet == "Non-vegetarian":
        return True
    if food["diet"] == "unknown":  # e.g. packaged item with no ingredient analysis: don't assume it fits
        return diet == "Lactose-free" and not food["dairy"]
    if diet == "Vegetarian":
        return food["diet"] in ("vegan", "vegetarian")
    if diet == "Vegan":
        return food["diet"] == "vegan"
    if diet == "Lactose-free":
        return not food["dairy"]
    return True


ALIASES = {"dairy": "milk", "lactose": "milk", "wheat": "gluten", "nuts": "nut", "shellfish": "prawn"}


def allergy_tokens(allergies: str) -> list[str]:
    toks = [t.strip() for t in (allergies or "").lower().replace(";", ",").split(",") if t.strip()]
    return [ALIASES.get(t, t) for t in toks]


def allergy_hit(food: dict, allergies: str) -> bool:
    toks = allergy_tokens(allergies)
    hay = food["allergens"] + [food["name"].lower()]
    return any(t in h or h in t for t in toks for h in hay if h)
